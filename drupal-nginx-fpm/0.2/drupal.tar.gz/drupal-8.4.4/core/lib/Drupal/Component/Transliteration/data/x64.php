<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'chan', 'ge', 'lou', 'zong', 'geng', 'jiao', 'gou', 'qin', 'rong', 'que', 'chou', 'chuai', 'zhan', 'sun', 'sun', 'bo',
  0x10 => 'chu', 'rong', 'bang', 'cuo', 'sao', 'ke', 'yao', 'dao', 'zhi', 'nu', 'la', 'jian', 'sou', 'qiu', 'gao', 'xian',
  0x20 => 'shuo', 'sang', 'jin', 'mie', 'e', 'chui', 'nuo', 'shan', 'ta', 'zha', 'tang', 'pan', 'ban', 'da', 'li', 'tao',
  0x30 => 'hu', 'zhi', 'wa', 'hua', 'qian', 'wen', 'qiang', 'tian', 'zhen', 'e', 'xie', 'nuo', 'quan', 'cha', 'zha', 'ge',
  0x40 => 'wu', 'en', 'she', 'kang', 'she', 'shu', 'bai', 'yao', 'bin', 'sou', 'tan', 'sa', 'chan', 'suo', 'jiu', 'chong',
  0x50 => 'chuang', 'guai', 'bing', 'feng', 'shuai', 'di', 'qi', 'sou', 'zhai', 'lian', 'cheng', 'chi', 'guan', 'lu', 'luo', 'lou',
  0x60 => 'zong', 'gai', 'hu', 'zha', 'chuang', 'tang', 'hua', 'cui', 'nai', 'mo', 'jiang', 'gui', 'ying', 'zhi', 'ao', 'zhi',
  0x70 => 'nie', 'man', 'chan', 'kou', 'chu', 'she', 'tuan', 'jiao', 'mo', 'mo', 'zhe', 'can', 'keng', 'biao', 'jiang', 'yin',
  0x80 => 'gou', 'qian', 'liao', 'ji', 'ying', 'jue', 'pie', 'pie', 'lao', 'dun', 'xian', 'ruan', 'gui', 'zan', 'yi', 'xian',
  0x90 => 'cheng', 'cheng', 'sa', 'nao', 'hong', 'si', 'han', 'guang', 'da', 'zun', 'nian', 'lin', 'zheng', 'hui', 'zhuang', 'jiao',
  0xA0 => 'ji', 'cao', 'dan', 'dan', 'che', 'bo', 'che', 'jue', 'fu', 'liao', 'ben', 'fu', 'qiao', 'bo', 'cuo', 'zhuo',
  0xB0 => 'zhuan', 'wei', 'pu', 'qin', 'dun', 'nian', 'hua', 'xie', 'lu', 'jiao', 'cuan', 'ta', 'han', 'qiao', 'wo', 'jian',
  0xC0 => 'gan', 'yong', 'lei', 'nang', 'lu', 'shan', 'zhuo', 'ze', 'pu', 'chuo', 'ji', 'dang', 'se', 'cao', 'qing', 'qing',
  0xD0 => 'huan', 'jie', 'qin', 'kuai', 'dan', 'xie', 'ka', 'pi', 'bai', 'ao', 'ju', 'ye', 'e', 'meng', 'sou', 'mi',
  0xE0 => 'ji', 'tai', 'zhuo', 'dao', 'xing', 'lan', 'ca', 'ju', 'ye', 'ru', 'ye', 'ye', 'ni', 'wo', 'ji', 'bin',
  0xF0 => 'ning', 'ge', 'zhi', 'zhi', 'kuo', 'mo', 'jian', 'xie', 'lie', 'tan', 'bai', 'sou', 'lu', 'lue', 'rao', 'ti',
];
