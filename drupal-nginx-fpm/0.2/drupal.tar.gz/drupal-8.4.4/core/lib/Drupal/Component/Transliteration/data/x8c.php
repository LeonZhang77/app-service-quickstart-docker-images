<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'yu', 'shui', 'shen', 'diao', 'chan', 'liang', 'zhun', 'sui', 'tan', 'shen', 'yi', 'mou', 'chen', 'die', 'huang', 'jian',
  0x10 => 'xie', 'xue', 'ye', 'wei', 'e', 'yu', 'xuan', 'chan', 'zi', 'an', 'yan', 'di', 'mi', 'pian', 'xu', 'mo',
  0x20 => 'dang', 'su', 'xie', 'yao', 'bang', 'shi', 'qian', 'mi', 'jin', 'man', 'zhe', 'jian', 'miu', 'tan', 'zen', 'qiao',
  0x30 => 'lan', 'pu', 'jue', 'yan', 'qian', 'zhan', 'chen', 'gu', 'qian', 'hong', 'xia', 'ji', 'hong', 'han', 'hong', 'xi',
  0x40 => 'xi', 'huo', 'liao', 'han', 'du', 'long', 'dou', 'jiang', 'qi', 'shi', 'li', 'deng', 'wan', 'bi', 'shu', 'xian',
  0x50 => 'feng', 'zhi', 'zhi', 'yan', 'yan', 'shi', 'chu', 'hui', 'tun', 'yi', 'tun', 'yi', 'jian', 'ba', 'hou', 'e',
  0x60 => 'chu', 'xiang', 'huan', 'jian', 'ken', 'gai', 'ju', 'fu', 'xi', 'bin', 'hao', 'yu', 'zhu', 'jia', 'fen', 'xi',
  0x70 => 'bo', 'wen', 'huan', 'bin', 'di', 'zong', 'fen', 'yi', 'zhi', 'bao', 'chai', 'an', 'pi', 'na', 'pi', 'gou',
  0x80 => 'na', 'you', 'diao', 'mo', 'si', 'xiu', 'huan', 'kun', 'he', 'hao', 'mo', 'han', 'mao', 'li', 'ni', 'bi',
  0x90 => 'yu', 'jia', 'tuan', 'mao', 'pi', 'xi', 'e', 'ju', 'mo', 'chu', 'tan', 'huan', 'jue', 'bei', 'zhen', 'yuan',
  0xA0 => 'fu', 'cai', 'gong', 'te', 'yi', 'hang', 'wan', 'pin', 'huo', 'fan', 'tan', 'guan', 'ze', 'zhi', 'er', 'zhu',
  0xB0 => 'shi', 'bi', 'zi', 'er', 'gui', 'pian', 'bian', 'mai', 'dai', 'sheng', 'kuang', 'fei', 'tie', 'yi', 'chi', 'mao',
  0xC0 => 'he', 'bi', 'lu', 'lin', 'hui', 'gai', 'pian', 'zi', 'jia', 'xu', 'zei', 'jiao', 'gai', 'zang', 'jian', 'ying',
  0xD0 => 'xun', 'zhen', 'she', 'bin', 'bin', 'qiu', 'she', 'chuan', 'zang', 'zhou', 'lai', 'zan', 'ci', 'chen', 'shang', 'tian',
  0xE0 => 'pei', 'geng', 'xian', 'mai', 'jian', 'sui', 'fu', 'tan', 'cong', 'cong', 'zhi', 'ji', 'zhang', 'du', 'jin', 'xiong',
  0xF0 => 'chun', 'yun', 'bao', 'zai', 'lai', 'feng', 'cang', 'ji', 'sheng', 'yi', 'zhuan', 'fu', 'gou', 'sai', 'ze', 'liao',
];
